
import asyncio
import random
from aiomultiprocess import Pool
import time
from asyncio.exceptions import TimeoutError
from colorama import Fore, init
import requests
import json
init()
PU = []
import re
import aiohttp
import random
import json
import time
import sys
import os
import asyncio
import bs4
from datetime import datetime
data_ora_curenta = datetime.now()
format_data_ora = data_ora_curenta.strftime("%H:%M:%Y")

with open('urls.txt', 'r', encoding='utf-8', errors='ignore') as f:
    x = 0
    for line in f:
        x+=1
        y = line.strip()
        PU.append(f'{x}:{y}')

async def main(qs):
    qcount = qs.split(':')[0]
    q = qs.split(':')[1]
    url = f'http://localhost:3000?id={q}'
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            try:
                if response.status == 200:
                    page_content = await response.text()
                    soup = bs4.BeautifulSoup(page_content, 'html5lib') 
                    # element = soup.find_all('div', class_='qLRx3b tjvcx GvPZzd cHaqb')
                    element = soup.select('.qLRx3b.tjvcx.GvPZzd.cHaqb')
                    # with open('text.html','w', encoding="utf-8") as f:
                    #     f.write(str(page_content))
                    urls = []
                    for rex in set(element):
                        if 'twitter' in str(rex.text):
                            with open('result/toal_extract.txt', 'a', encoding='utf-8') as f:
                                f.write(q + ' - ' + rex.text.strip() + '\n')
                            parts = rex.text.split(" › ")
                            username = parts[1]
                            if username != 'status':
                                urls.append(username)

                    for result in set(urls):
                        with open('result/good.txt', 'a', encoding='utf-8') as f:
                            if len(result.strip()) > 4:
                                f.write(result.strip() + '\n')
                    datas = len(set(urls))
                    if datas > 0:
                        print(f'{Fore.MAGENTA}[{Fore.GREEN} {format_data_ora} {Fore.MAGENTA}] [{Fore.GREEN} {qcount} / {q} {Fore.MAGENTA}] {Fore.GREEN } {datas} {Fore.MAGENTA}{Fore.RESET}')
                    else:
                        print(f'{Fore.MAGENTA}[{Fore.RED} {format_data_ora} {Fore.MAGENTA}] [{Fore.RED} {qcount} / {q} {Fore.MAGENTA}] {Fore.GREEN } {datas} {Fore.MAGENTA}{Fore.RESET}')

                else:
                    print(f'{Fore.MAGENTA}[{Fore.GREEN} {format_data_ora} {Fore.MAGENTA}] [{Fore.RED} {qcount} / {q} {Fore.MAGENTA}] {Fore.YELLOW}HTTP GET ERROR {Fore.MAGENTA}[{Fore.RED} {status_code} {Fore.MAGENTA}] {Fore.RESET}')
                    print(f"Conținutul răspunsului: {content}")
            except Exception as e:
                print(e)
                pass
async def x():
        count =1
        n = 15
        final = [PU[i * n:(i + 1) * n] for i in range((len(PU) + n - 1) // n )]
        for x in final:
            count+=1
            async with Pool() as pool:
                async for result in pool.map(main,x):
                    continue 


if __name__ == '__main__':
    try:
        asyncio.run(x())
    except Exception as e:
        print(e)
    except:
        pass
# https://www.myexternalip.com/raw
