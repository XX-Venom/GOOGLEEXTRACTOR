const express = require('express');
const puppeteer = require('puppeteer');
const app = express();
const port = 3000;
async function runPuppeteer(id, proxy) {
  process.setMaxListeners(20);

    let userProxy = true
    let username = ''
    let password = ''
    let host = ''
    id = id.trim()
    host = 'dc.sm-pr.proxies.gg:8080'
    username = 'IPv4D_4SsqCYifgR'
    password = 'mA5GX24njGWAAHi'

    if (userProxy) {
      var browser = await puppeteer.launch({
        headless: "now",
        ignoreDefaultArgs: ["--disable-extensions"],
        args: ['--no-sandbox', '--disable-setuid-sandbox', `--proxy-server=${host}`]
      });
    } else {
      var browser = await puppeteer.launch({
        headless: "now",
        ignoreDefaultArgs: ["--disable-extensions"],
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
    }
  try {
  const page = await browser.newPage();
  if(userProxy){
        page.authenticate({
            username: `${username}`,
            password: `${password}`
        })
  }
  await page.goto(`https://www.google.com/search?q=${id}+site%3Atwitter.com#ip=1`, { waitUntil: 'domcontentloaded' });
  const pageTitle = await page.title();
  await page.setRequestInterception(true);
  page.on('request', (request) => {
    if (request.resourceType() === 'image') {
      request.abort();
    } else {
      request.continue();
    }
  });
    const content = await page.content();
    return content
  } catch (error) {
    console.error('Eroare Puppeteer:', error);
    throw error;
  }finally {
    await browser.close();
  }


}
// ?id=${id}
app.get('/', async (req, res) => {
  try {
    const id = req.query.id;
    console.log(id)
    const proxy = req.query.proxy
    const xy = await runPuppeteer(id, proxy);
    res.send(xy);

  } catch (error) {
    console.error('Eroare Puppeteer:', error);
    res.status(500).send('Eroare internă');
  }
});



app.listen(port, () => {
  console.log(`Serverul ascultă la http://localhost:${port}`);
});
